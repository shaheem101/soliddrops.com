---
layout: default
title: "About Soliddrops | Epoxy Flooring Experts"
description: "Learn about Soliddrops, Saudi Arabia’s leading provider of epoxy flooring and industrial coating solutions. Discover our vision, partnerships, and commitment to Vision 2030 projects."
lang: en
dir: ltr
canonical_url: "https://fast.soliddrops.com/about/"
---

<section class="hero">
  <div class="container">
    <h1>About Soliddrops</h1>
    <p>Building durable, hygienic and beautiful floors that power Saudi Arabia’s industrial and commercial transformation.</p>
  </div>
</section>

<section class="content container">
  <h2>Our Mission</h2>
  <p>Soliddrops was founded with a single mission: to deliver world‑class flooring solutions that support Saudi Arabia’s journey towards Vision 2030. From industrial plants and warehouses to luxury resorts and office towers, our flooring systems keep the Kingdom’s most ambitious projects running smoothly.</p>

  <h2>Certified Expertise</h2>
  <p>Our team consists of certified applicators trained by global manufacturers such as Sika, BASF and Stonhard. We adhere to Saudi Building Code (SBC) requirements and international standards (ASTM, ISO, GMP) to ensure every installation meets or exceeds expectations.</p>

  <h2>Local Knowledge, Global Partners</h2>
  <p>By partnering with leading material suppliers, we offer solutions tailored to Saudi Arabia’s diverse environments—from desert heat and dust storms to humid coastal climates and petrochemical exposure. Our local presence in Riyadh, Jeddah and Dammam ensures responsive service and detailed understanding of each region’s needs.</p>

  <h2>Commitment to Sustainability</h2>
  <p>We prioritise sustainable practices, including low‑VOC materials, efficient installation methods and long‑lasting systems that reduce waste over time. Our polished concrete and vinyl flooring options provide environmentally conscious alternatives for modern architecture.</p>

  {% include cta.html %}
</section>