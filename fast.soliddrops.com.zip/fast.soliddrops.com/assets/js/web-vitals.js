// Web Vitals monitoring for GitHub Pages
import {onCLS, onINP, onLCP} from 'https://unpkg.com/web-vitals@3/dist/web-vitals.attribution.js';

// Send metrics to analytics
function sendToAnalytics(metric) {
  // Replace with actual analytics endpoint
  console.log('Web Vitals:', metric);
  
  // Example: Send to Google Analytics 4
  if (typeof gtag !== 'undefined') {
    gtag('event', metric.name, {
      value: Math.round(metric.name === 'CLS' ? metric.value * 1000 : metric.value),
      metric_id: metric.id,
      metric_value: metric.value,
      metric_delta: metric.delta,
      custom_parameter: 'web_vitals'
    });
  }
}

// Monitor Core Web Vitals
onCLS(sendToAnalytics);
onINP(sendToAnalytics); 
onLCP(sendToAnalytics);

// Performance monitoring
const observer = new PerformanceObserver((list) => {
  for (const entry of list.getEntries()) {
    if (entry.entryType === 'navigation') {
      console.log('Navigation timing:', entry);
    }
    
    if (entry.entryType === 'largest-contentful-paint') {
      console.log('LCP timing:', entry.startTime);
    }
  }
});

observer.observe({entryTypes: ['navigation', 'largest-contentful-paint']});